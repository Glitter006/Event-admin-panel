import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function AddEvent() {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [venue, setVenue] = useState('');

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    const newEvent = {
      name,
      description,
      date,
      venue
    };

    axios.post('http://localhost:5000/api/events', newEvent)
      .then(res => {
        alert("Event Added Successfully!");
        navigate('/');
      })
      .catch(err => {
        console.log(err);
        alert("Error adding event");
      });
  };

  return (
    <div className="container">
      <div className="form-box">
        <h3>Add New Event</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Event Name:</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Event Description:</label>
            <textarea
              required
              rows="3"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            ></textarea>
          </div>

          <div className="form-group">
            <label>Event Date:</label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Venue:</label>
            <input
              type="text"
              required
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
            />
          </div>

          <button type="submit" className="btn-submit">Add Event</button>
        </form>
      </div>
    </div>
  );
}

export default AddEvent;
