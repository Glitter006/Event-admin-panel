import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function EditEvent() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('');
  const [venue, setVenue] = useState('');
  const [totalRegistrations, setTotalRegistrations] = useState(0);

  useEffect(() => {
    axios.get('http://localhost:5000/api/events/' + id)
      .then(res => {
        const item = res.data.data ? res.data.data : res.data;
        if (item) {
          setName(item.name || '');
          setDescription(item.description || '');
          setDate(item.date || '');
          setVenue(item.venue || '');
          setTotalRegistrations(item.totalRegistrations || 0);
        }
      })
      .catch(err => {
        console.log(err);
      });
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const updatedEvent = {
      name,
      description,
      date,
      venue,
      totalRegistrations
    };

    axios.put('http://localhost:5000/api/events/' + id, updatedEvent)
      .then(res => {
        alert("Event Updated Successfully!");
        navigate('/');
      })
      .catch(err => {
        console.log(err);
        alert("Error updating event");
      });
  };

  return (
    <div className="container">
      <div className="form-box">
        <h3>Update Event</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Event Name:</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Event Description:</label>
            <textarea
              required
              rows="3"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            ></textarea>
          </div>

          <div className="form-group">
            <label>Event Date:</label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Venue:</label>
            <input
              type="text"
              required
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Total Registrations:</label>
            <input
              type="number"
              value={totalRegistrations}
              onChange={(e) => setTotalRegistrations(e.target.value)}
            />
          </div>

          <button type="submit" className="btn-submit">Update Event</button>
        </form>
      </div>
    </div>
  );
}

export default EditEvent;
