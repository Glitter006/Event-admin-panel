import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Dashboard() {
  const [events, setEvents] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    getEvents();
  }, []);

  const getEvents = () => {
    axios.get('http://localhost:5000/api/events')
      .then(res => {
        // Safe check whether API returns array or { data: [...] }
        const eventList = Array.isArray(res.data)
          ? res.data
          : (res.data.data || []);
        setEvents(eventList);
      })
      .catch(err => {
        console.log('Error fetching events:', err);
      });
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this event?")) {
      axios.delete('http://localhost:5000/api/events/' + id)
        .then(() => {
          alert("Event deleted successfully");
          getEvents();
        })
        .catch(err => {
          console.log(err);
        });
    }
  };

  return (
    <div className="container">
      <div className="header-row">
        <h3>Event Dashboard</h3>
      </div>

      <table className="event-table">
        <thead>
          <tr>
            <th>Event ID</th>
            <th>Event Name</th>
            <th>Event Date</th>
            <th>Venue</th>
            <th>Total Registrations</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {!Array.isArray(events) || events.length === 0 ? (
            <tr>
              <td colSpan="6" style={{ textAlign: 'center' }}>No events found</td>
            </tr>
          ) : (
            events.map(event => (
              <tr key={event._id}>
                <td>{event._id}</td>
                <td>
                  <strong>{event.name}</strong>
                  <br />
                  <small>{event.description}</small>
                </td>
                <td>{event.date}</td>
                <td>{event.venue}</td>
                <td>{event.totalRegistrations || 0}</td>
                <td>
                  <button
                    className="btn-update"
                    onClick={() => navigate('/edit/' + event._id)}
                  >
                    Update
                  </button>
                  <button
                    className="btn-delete"
                    onClick={() => handleDelete(event._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Dashboard;
