import React from 'react';
import { NavLink } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="navbar">
      <h2>Event Management Admin</h2>
      <div className="nav-links">
        <NavLink
          to="/"
          className={({ isActive }) => (isActive ? 'nav-tab active' : 'nav-tab')}
        >
          Dashboard
        </NavLink>
        <NavLink
          to="/add"
          className={({ isActive }) => (isActive ? 'nav-tab active' : 'nav-tab')}
        >
          Add Event
        </NavLink>
      </div>
    </nav>
  );
}

export default Navbar;
