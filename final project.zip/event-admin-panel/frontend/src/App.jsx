import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import AddEvent from './components/AddEvent';
import EditEvent from './components/EditEvent';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/add" element={<AddEvent />} />
          <Route path="/edit/:id" element={<EditEvent />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
