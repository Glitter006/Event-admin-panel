const mongoose = require('mongoose');

// Connect to MongoDB Atlas
const connectDB = async () => {
  const mongoUri =
    process.env.MONGO_URI ||
    'mongodb+srv://GlitterShibu:glittergloria@cluster0.sqzyrcl.mongodb.net/eventDB?retryWrites=true&w=majority';

  try {
    const conn = await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 5000 // 5 seconds timeout
    });
    console.log(`MongoDB Connected Successfully: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB Connection Warning: ${error.message}`);
    console.log('Tip: Ensure your current IP is whitelisted in MongoDB Atlas (Network Access -> Add 0.0.0.0/0).');
  }
};

module.exports = connectDB;
