const Event = require('../models/Event');

// get all events
const getEvents = (req, res) => {
  Event.find()
    .then(events => res.json(events))
    .catch(err => res.status(400).json('Error: ' + err));
};

// get single event by id
const getEventById = (req, res) => {
  Event.findById(req.params.id)
    .then(event => res.json(event))
    .catch(err => res.status(400).json('Error: ' + err));
};

// add new event
const createEvent = (req, res) => {
  const name = req.body.name;
  const description = req.body.description;
  const date = req.body.date;
  const venue = req.body.venue;
  const totalRegistrations = Number(req.body.totalRegistrations) || 0;

  const newEvent = new Event({
    name,
    description,
    date,
    venue,
    totalRegistrations
  });

  newEvent.save()
    .then(() => res.json('Event added successfully!'))
    .catch(err => res.status(400).json('Error: ' + err));
};

// update event
const updateEvent = (req, res) => {
  Event.findById(req.params.id)
    .then(event => {
      event.name = req.body.name;
      event.description = req.body.description;
      event.date = req.body.date;
      event.venue = req.body.venue;
      if (req.body.totalRegistrations !== undefined) {
        event.totalRegistrations = Number(req.body.totalRegistrations);
      }

      event.save()
        .then(() => res.json('Event updated successfully!'))
        .catch(err => res.status(400).json('Error: ' + err));
    })
    .catch(err => res.status(400).json('Error: ' + err));
};

// delete event
const deleteEvent = (req, res) => {
  Event.findByIdAndDelete(req.params.id)
    .then(() => res.json('Event deleted successfully!'))
    .catch(err => res.status(400).json('Error: ' + err));
};

module.exports = {
  getEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent
};
