# Event Management Admin Portal

This project was built for the 2nd year computer science lab evaluation test. 

The app is a MERN stack event registration panel with a React frontend and Express/MongoDB backend. It allows creating events, viewing them in a dashboard, updating details, and deleting records.

Setup:
1. Run backend: open terminal in /backend, run npm install and then npm start. Runs on port 5000.
2. Run frontend: open terminal in /frontend, run npm install and then npm start. Runs on port 3000.

MongoDB Atlas connection string is inside the backend .env file.
